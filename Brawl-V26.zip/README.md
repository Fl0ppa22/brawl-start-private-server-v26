<h1 align="center">Welcome to Classic-Brawl v26</h1>

Open source Brawl Stars server emulator for version 26 of the game!


![ScreenShot](https://media.discordapp.net/attachments/1266505712494706801/1266505767486230678/BnCfluYh.png?ex=66a564e9&is=66a41369&hm=7210524a1a9b728e246b6a3af8608e6903f635bf4fe0c9f19a9641c8dac98a72&=&format=webp&quality=lossless&width=853&height=480) 
![ScreenShot](https://media.discordapp.net/attachments/1266505712494706801/1266505768044199967/1y8EERPM.png?ex=66a564e9&is=66a41369&hm=01f28e4f95180443450efa6ab0ca571992d3c2fc3f37ca87db5550a73d988c6d&=&format=webp&quality=lossless&width=853&height=480)
![ScreenShot](https://media.discordapp.net/attachments/1266505712494706801/1266505768543457424/4kA5OqmH.png?ex=66a564e9&is=66a41369&hm=e2693c2fdffe23e755507b60c68b45d4dee236f24285b21adb1f5461d9e1fd55&=&format=webp&quality=lossless&width=853&height=480)
## What's working ?

- Home
  - win trophies
  - boxes working
  - leaderboard
  - add friends
- Shop
  - buy boxes
  - buy coins
  - buy brawlers
- Club
  - push trophies
  - enter club
  - create club
  - chat
  - view member 

...and much more!


## Configure client
To connect to your server, you need a custom client. Here the only solution is to use a [client](https://www.mediafire.com/file/vxi0dn1iribr96s/brawl+stars+v26+pachet.apk/file). Just replace the IP in the frida-gadget config with yours (```/lib/armeabi-v7a/libgg.config.so```) ```{"interaction":{"interaction":{"type":"script","path":"libscript.so","on_change":"reload","parameters":{"redirectHost":"YOUR_IP","relocate":true}}}```







#### Need help? Join [our Discord support server](https://discord.gg/nwMpKeBG3X)




## Authors

* autor: Foxy_tp